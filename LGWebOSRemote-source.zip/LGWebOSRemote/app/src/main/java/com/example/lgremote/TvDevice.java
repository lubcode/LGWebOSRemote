package com.example.lgremote;

public final class TvDevice {
    public final String ip;
    public final String name;
    public TvDevice(String ip, String name) {
        this.ip = ip;
        this.name = (name == null || name.trim().isEmpty()) ? "LG webOS TV" : name;
    }
    @Override public String toString() { return name + "  ·  " + ip; }
}
