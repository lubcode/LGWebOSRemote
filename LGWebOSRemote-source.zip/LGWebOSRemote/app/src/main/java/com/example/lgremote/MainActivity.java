package com.example.lgremote;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity implements WebOsController.Listener {
    private static final int BG = Color.rgb(15, 20, 34), PANEL = Color.rgb(28, 37, 56);
    private static final int ACCENT = Color.rgb(82, 132, 255), WHITE = Color.rgb(242, 246, 255);
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private ArrayList<TvDevice> devices = new ArrayList<>();
    private WebOsController tv;
    private SharedPreferences prefs;
    private TextView status, tvTitle, volumeText;
    private boolean scanning;
    private boolean isConnected;
    private String selectedIp = "";
    private String selectedName = "";
    private LinearLayout root;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences("lg_remote", MODE_PRIVATE);
        tv = new WebOsController(this, this);
        buildUi();
        scan();
    }
    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable background(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView label(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(26));
        scroll.addView(root); setContentView(scroll);

        TextView title = label("LG  REMOTE", 25, WHITE, true);
        root.addView(title);
        TextView subtitle = label("Локальное управление webOS", 13, 0xFFA9B4CC, false);
        subtitle.setPadding(0, dp(5), 0, dp(18)); root.addView(subtitle);

        LinearLayout deviceRow = new LinearLayout(this); deviceRow.setOrientation(LinearLayout.VERTICAL);
        deviceRow.setPadding(dp(16), dp(14), dp(16), dp(14)); deviceRow.setBackground(background(PANEL, 18));
        tvTitle = label("Поиск телевизора…", 17, WHITE, true); deviceRow.addView(tvTitle);
        status = label("Ищем LG в вашей сети", 12, 0xFFA8BADB, false);
        status.setPadding(0, dp(6), 0, dp(12)); deviceRow.addView(status);
        LinearLayout options = row();
        Button choose = button("Выбрать ТВ", ACCENT); choose.setOnClickListener(v -> selectTv());
        Button refresh = button("Обновить", 0xFF3D506F); refresh.setOnClickListener(v -> scan());
        addWeighted(options, choose); addWeighted(options, refresh);
        deviceRow.addView(options); root.addView(deviceRow);

        addGap(18);
        LinearLayout power = row();
        Button off = button("⏻   ВЫКЛЮЧИТЬ", 0xFFC74959);
        off.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Выключить телевизор?")
                .setPositiveButton("Выключить", (d,w) -> tv.action("ssap://system/turnOff"))
                .setNegativeButton("Отмена", null).show());
        addWeighted(power, off); root.addView(power);

        addGap(22); section("НАВИГАЦИЯ");
        addDpad();
        addGap(12);
        LinearLayout nav = row();
        addWeighted(nav, actionButton("↶  Назад", "BACK"));
        addWeighted(nav, actionButton("⌂  Домой", "HOME"));
        root.addView(nav);
        addGap(22); section("ЗВУК И КАНАЛЫ");
        volumeText = label("Громкость: —", 14, 0xFFAFC3E4, false);
        volumeText.setGravity(Gravity.CENTER); volumeText.setPadding(0, dp(4), 0, dp(12)); root.addView(volumeText);
        LinearLayout sound = row();
        addWeighted(sound, commandButton("VOL −", "ssap://audio/volumeDown"));
        Button mute = button("Без звука", 0xFF405879); mute.setOnClickListener(v -> tv.toggleMute()); addWeighted(sound, mute);
        addWeighted(sound, commandButton("VOL +", "ssap://audio/volumeUp")); root.addView(sound);
        addGap(10);
        LinearLayout channels = row();
        addWeighted(channels, commandButton("CH −", "ssap://tv/channelDown"));
        addWeighted(channels, commandButton("CH +", "ssap://tv/channelUp")); root.addView(channels);

        addGap(22); section("ПРИЛОЖЕНИЯ И ВХОДЫ");
        LinearLayout apps = row();
        Button youtube = button("▶  YouTube", 0xFF344566); youtube.setOnClickListener(v -> tv.launch("youtube.leanback.v4"));
        Button hdmi = button("▣  HDMI", 0xFF344566); hdmi.setOnClickListener(v -> tv.showInputs());
        addWeighted(apps, youtube); addWeighted(apps, hdmi); root.addView(apps);
        addGap(12);
        Button reconnect = button("Повторить подключение", 0xFF26344C);
        reconnect.setOnClickListener(v -> { if (!selectedIp.isEmpty()) tv.connect(selectedIp); else scan(); });
        root.addView(reconnect, new LinearLayout.LayoutParams(-1, dp(49)));
        addGap(10);
        TextView note = label("Первый запуск: подтвердите подключение на экране ТВ.\nПосле этого устройство запоминается автоматически.", 12, 0xFF899AB4, false);
        note.setGravity(Gravity.CENTER); root.addView(note);
    }
    private void section(String text) {
        TextView t = label(text, 12, 0xFF96ABD3, true);
        t.setPadding(dp(3), 0, 0, dp(12)); root.addView(t);
    }
    private void addDpad() {
        LinearLayout dpad = new LinearLayout(this); dpad.setOrientation(LinearLayout.VERTICAL);
        dpad.setPadding(dp(12), dp(12), dp(12), dp(12)); dpad.setBackground(background(PANEL, 24));
        LinearLayout top = row(), middle = row(), bottom = row();
        addWeighted(top, spacer()); addWeighted(top, actionButton("▲", "UP")); addWeighted(top, spacer());
        addWeighted(middle, actionButton("◀", "LEFT"));
        addWeighted(middle, actionButton("OK", "ENTER", ACCENT));
        addWeighted(middle, actionButton("▶", "RIGHT"));
        addWeighted(bottom, spacer()); addWeighted(bottom, actionButton("▼", "DOWN")); addWeighted(bottom, spacer());
        dpad.addView(top); dpad.addView(middle); dpad.addView(bottom); root.addView(dpad);
    }
    private Button spacer() { Button b = button("", PANEL); b.setVisibility(View.INVISIBLE); return b; }
    private LinearLayout row() { LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); return r; }
    private Button button(String text, int bg) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false);
        b.setTextSize(14); b.setTextColor(WHITE); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(background(bg, 15)); b.setElevation(0); b.setPadding(dp(5), 0, dp(5), 0);
        return b;
    }
    private void addWeighted(LinearLayout row, View view) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(58), 1);
        p.setMargins(dp(4), dp(3), dp(4), dp(3)); row.addView(view, p);
    }
    private Button actionButton(String title, String key) { return actionButton(title, key, 0xFF344566); }
    private Button actionButton(String title, String key, int color) {
        Button b = button(title, color); b.setTextSize(title.length() <= 2 ? 19 : 14);
        b.setOnClickListener(v -> tv.button(key)); return b;
    }
    private Button commandButton(String title, String command) {
        Button b = button(title, 0xFF344566); b.setOnClickListener(v -> tv.action(command)); return b;
    }
    private void addGap(int h) { root.addView(new View(this), new LinearLayout.LayoutParams(1, dp(h))); }
    private void selectTv() {
        if (devices.isEmpty()) { scan(); return; }
        String[] names = new String[devices.size()];
        for (int i=0; i<devices.size(); i++) names[i] = devices.get(i).toString();
        new AlertDialog.Builder(this).setTitle("Выберите телевизор")
                .setItems(names, (dialog, index) -> choose(devices.get(index))).setNegativeButton("Отмена", null).show();
    }
    private void choose(TvDevice device) {
        selectedIp = device.ip; selectedName = device.name;
        prefs.edit().putString("last_ip", selectedIp).putString("last_name", selectedName).apply();
        tvTitle.setText(selectedName);
        tv.connect(selectedIp);
    }
    private void scan() {
        if (scanning) return;
        scanning = true;
        status.setText("Поиск телевизоров в локальной сети…");
        String lastIp = prefs.getString("last_ip", "");
        if (!lastIp.isEmpty() && selectedIp.isEmpty()) {
            selectedIp = lastIp;
            selectedName = prefs.getString("last_name", "LG webOS TV");
            tvTitle.setText(selectedName);
            tv.connect(lastIp);
        }
        io.execute(() -> {
            ArrayList<TvDevice> found = TvDiscovery.scan(getApplicationContext());
            ui.post(() -> {
                scanning = false;
                devices = found;
                if (devices.size() == 1 && selectedIp.isEmpty()) {
                    choose(devices.get(0));
                } else if (devices.size() > 1 && selectedIp.isEmpty()) {
                    tvTitle.setText("Найдено телевизоров: " + devices.size());
                    status.setText("Выберите телевизор для подключения");
                    selectTv();
                } else if (devices.isEmpty() && selectedIp.isEmpty()) {
                    tvTitle.setText("Телевизор не найден");
                    status.setText("Включите ТВ и проверьте локальную сеть. Нажмите «Обновить».");
                } else if (selectedIp.isEmpty()) {
                    status.setText("Найдено телевизоров: " + devices.size());
                } else if (!isConnected) {
                    boolean selectedFound = false;
                    for (TvDevice d: devices) if (d.ip.equals(selectedIp)) selectedFound = true;
                    if (!selectedFound && devices.size() == 1) choose(devices.get(0));
                }
            });
        });
    }
    @Override public void state(String message, boolean connected) {
        isConnected = connected;
        status.setText(message);
    }
    @Override public void volume(int value, boolean muted) {
        volumeText.setText("Громкость: " + (value >= 0 ? value : "—") + (muted ? "  ·  без звука" : ""));
    }
    @Override public void inputs(JSONArray inputs) {
        ArrayList<String> ids = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();
        for (int i = 0; i < inputs.length(); i++) {
            JSONObject item = inputs.optJSONObject(i);
            if (item == null) continue;
            String id = item.optString("id");
            if (id.isEmpty()) continue;
            ids.add(id);
            labels.add(item.optString("label", id));
        }
        if (ids.isEmpty()) {
            new AlertDialog.Builder(this).setMessage("Телевизор не вернул список доступных входов")
                    .setPositiveButton("OK", null).show(); return;
        }
        new AlertDialog.Builder(this).setTitle("Выберите вход")
                .setItems(labels.toArray(new String[0]), (d, which) -> tv.selectInput(ids.get(which)))
                .setNegativeButton("Отмена", null).show();
    }
    @Override protected void onDestroy() {
        tv.close(); io.shutdownNow(); super.onDestroy();
    }
}
