package com.example.lgremote;

import android.content.Context;
import android.net.wifi.WifiManager;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class TvDiscovery {
    private TvDiscovery() { }
    public static ArrayList<TvDevice> scan(Context context) {
        Map<String, TvDevice> result = new LinkedHashMap<>();
        WifiManager wm = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        WifiManager.MulticastLock lock = null;
        try {
            if (wm != null) {
                lock = wm.createMulticastLock("lg-webos-ssdp");
                lock.setReferenceCounted(false);
                lock.acquire();
            }
            try (DatagramSocket socket = new DatagramSocket()) {
                socket.setReuseAddress(true);
                socket.setSoTimeout(700);
                InetAddress group = InetAddress.getByName("239.255.255.250");
                String[] targets = {
                        "urn:lge-com:service:webos-second-screen:1",
                        "urn:schemas-upnp-org:device:MediaRenderer:1",
                        "ssdp:all"
                };
                for (String target : targets) {
                    String request = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: " + target + "\r\n\r\n";
                    byte[] bytes = request.getBytes(StandardCharsets.US_ASCII);
                    socket.send(new DatagramPacket(bytes, bytes.length, group, 1900));
                }
                long end = System.currentTimeMillis() + 3600;
                while (System.currentTimeMillis() < end) {
                    try {
                        byte[] buf = new byte[8192];
                        DatagramPacket packet = new DatagramPacket(buf, buf.length);
                        socket.receive(packet);
                        String response = new String(packet.getData(), 0, packet.getLength(), StandardCharsets.UTF_8);
                        String ip = packet.getAddress().getHostAddress();
                        String location = header(response, "location");
                        String server = header(response, "server");
                        String st = header(response, "st");
                        String usn = header(response, "usn");
                        boolean lg = (server + st + usn).toLowerCase(Locale.ROOT).contains("lge")
                                || (server + st + usn).toLowerCase(Locale.ROOT).contains("webos")
                                || (server + st + usn).toLowerCase(Locale.ROOT).contains("lg ");
                        String name = "LG webOS TV";
                        if (location != null && !location.isEmpty()) {
                            try {
                                URI uri = URI.create(location);
                                // Prevent fetching descriptions from unrelated hosts.
                                if (ip.equals(uri.getHost())) {
                                    String xml = readDescription(location);
                                    String type = tag(xml, "manufacturer") + " " + tag(xml, "modelName") + " " + tag(xml, "deviceType");
                                    lg = lg || type.toLowerCase(Locale.ROOT).contains("lg electronics")
                                            || type.toLowerCase(Locale.ROOT).contains("lge")
                                            || type.toLowerCase(Locale.ROOT).contains("webos");
                                    String friendly = tag(xml, "friendlyName");
                                    if (!friendly.isEmpty()) name = friendly;
                                }
                            } catch (Exception ignored) { }
                        }
                        if (lg && !result.containsKey(ip)) result.put(ip, new TvDevice(ip, name));
                    } catch (java.net.SocketTimeoutException ignored) { }
                }
            }
        } catch (Exception ignored) { }
        finally { if (lock != null && lock.isHeld()) lock.release(); }
        return new ArrayList<>(result.values());
    }
    private static String readDescription(String location) {
        HttpURLConnection c = null;
        try {
            URL url = new URL(location);
            if (!"http".equals(url.getProtocol())) return "";
            c = (HttpURLConnection) url.openConnection();
            c.setConnectTimeout(900); c.setReadTimeout(900);
            try (InputStream stream = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] bytes = new byte[1024]; int n;
                while ((n = stream.read(bytes)) != -1 && out.size() < 32000) out.write(bytes, 0, n);
                return out.toString("UTF-8");
            }
        } catch (Exception ignored) { return ""; }
        finally { if (c != null) c.disconnect(); }
    }
    private static String tag(String body, String tag) {
        Matcher m = Pattern.compile("<(?:\\w+:)?" + tag + "[^>]*>([^<]+)</(?:\\w+:)?" + tag + ">", Pattern.CASE_INSENSITIVE).matcher(body);
        return m.find() ? m.group(1).trim() : "";
    }
    private static String header(String body, String key) {
        Matcher m = Pattern.compile("(?im)^" + key + ":\\s*(.*?)\\r?$", Pattern.MULTILINE).matcher(body);
        return m.find() ? m.group(1).trim() : "";
    }
}
