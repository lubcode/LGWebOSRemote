package com.example.lgremote;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

public final class WebOsController {
    public interface Listener {
        void state(String message, boolean connected);
        void volume(int value, boolean muted);
        void inputs(JSONArray inputs);
    }
    private final SharedPreferences prefs;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final AtomicInteger counter = new AtomicInteger(1);
    private final OkHttpClient client;
    private WebSocket socket;
    private WebSocket pointer;
    private String currentIp;
    private boolean registered;
    private int epoch;
    private boolean muted;

    public WebOsController(Context context, Listener listener) {
        this.listener = listener;
        this.prefs = context.getSharedPreferences("lg_remote", Context.MODE_PRIVATE);
        // LG TVs may serve a self-signed certificate on their LOCAL WebSocket endpoint.
        // This client is ONLY used for a user-selected local TV. Never reuse for internet services.
        OkHttpClient.Builder builder = new OkHttpClient.Builder()
                .connectTimeout(1800, TimeUnit.MILLISECONDS)
                .readTimeout(0, TimeUnit.MILLISECONDS)
                .pingInterval(25, TimeUnit.SECONDS);
        try {
            X509TrustManager localOnly = new X509TrustManager() {
                @Override public void checkClientTrusted(X509Certificate[] chain, String authType) { }
                @Override public void checkServerTrusted(X509Certificate[] chain, String authType) { }
                @Override public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            };
            SSLContext ssl = SSLContext.getInstance("TLS");
            ssl.init(null, new TrustManager[]{localOnly}, new SecureRandom());
            builder.sslSocketFactory(ssl.getSocketFactory(), localOnly);
            builder.hostnameVerifier((hostname, session) -> isLocalAddress(hostname));
        } catch (Exception ignored) { }
        client = builder.build();
    }
    private static boolean isLocalAddress(String h) {
        if (h == null) return false;
        if (h.matches("10\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}") ||
            h.matches("192\\.168\\.\\d{1,3}\\.\\d{1,3}")) return true;
        if (h.matches("172\\.(1[6-9]|2[0-9]|3[01])\\.\\d{1,3}\\.\\d{1,3}")) return true;
        return false;
    }
    public void connect(String ip) {
        if (!isLocalAddress(ip)) { state("Нужен адрес ТВ из домашней сети", false); return; }
        close();
        currentIp = ip;
        int current = ++epoch;
        state("Подключение к " + ip + "…", false);
        openSocket(ip, 3000, current, true);
    }
    private void openSocket(String ip, int port, int current, boolean fallback) {
        String scheme = port == 3001 ? "wss" : "ws";
        Request request = new Request.Builder().url(scheme + "://" + ip + ":" + port + "/").build();
        socket = client.newWebSocket(request, new WebSocketListener() {
            private boolean opened = false;
            @Override public void onOpen(WebSocket ws, Response response) {
                if (epoch != current) { ws.close(1000, "obsolete"); return; }
                opened = true;
                register(ws);
            }
            @Override public void onMessage(WebSocket ws, String message) {
                if (epoch == current) receive(message);
            }
            @Override public void onFailure(WebSocket ws, Throwable t, Response response) {
                if (epoch != current) return;
                registered = false;
                if (fallback && !opened) {
                    state("Пробую защищённое подключение…", false);
                    openSocket(ip, 3001, current, false);
                } else state("Нет соединения с ТВ. Проверьте, что он включён.", false);
            }
            @Override public void onClosed(WebSocket ws, int code, String reason) {
                if (epoch == current) { registered = false; state("Соединение закрыто", false); }
            }
        });
    }
    private static JSONObject registrationManifest() throws Exception {
        // Compatible webOS SSAP registration manifest based on the public PyWebOSTV client.
        String sig = "eyJhbGdvcml0aG0iOiJSU0EtU0hBMjU2Iiwia2V5SWQiOiJ0ZXN0LXNpZ25pbmctY2VydCIsInNpZ25hdHVyZVZlcnNpb24iOjF9.hrVRgjCwXVvE2OOSpDZ58hR+59aFNwYDyjQgKk3auukd7pcegmE2CzPCa0bJ0ZsRAcKkCTJrWo5iDzNhMBWRy aMOv5zWSrthlf7G128qvIlpMT0YNY+n/FaOHE73uLrS/g7swl3/qH/BGFG2Hu4RlL48eb3lLKqTt2xKHdCs6Cd4RMfJPYnzgvI4BNrFUKsjkcu+WD4OO2A27Pq1n+50cMchmcaXadJhGrOqH5YmHdOCj5NSHzJYrsW0HPlpuAx/ECMeIZYDh6RMqaFMoa7NQnAtw==".replace(" ", "");
        JSONObject signed = new JSONObject();
        signed.put("appId", "com.lge.test").put("created", "20140509")
            .put("localizedAppNames", new JSONObject().put("", "LG Remote App")
                .put("ko-KR", "리모컨 앱").put("zxx-XX", "ЛГ Rэмotэ AПП"))
            .put("localizedVendorNames", new JSONObject().put("", "LG Electronics"))
            .put("permissions", new JSONArray("[\"TEST_SECURE\",\"CONTROL_INPUT_TEXT\",\"CONTROL_MOUSE_AND_KEYBOARD\",\"READ_INSTALLED_APPS\",\"READ_LGE_SDX\",\"READ_NOTIFICATIONS\",\"SEARCH\",\"WRITE_SETTINGS\",\"WRITE_NOTIFICATION_ALERT\",\"CONTROL_POWER\",\"READ_CURRENT_CHANNEL\",\"READ_RUNNING_APPS\",\"READ_UPDATE_INFO\",\"UPDATE_FROM_REMOTE_APP\",\"READ_LGE_TV_INPUT_EVENTS\",\"READ_TV_CURRENT_TIME\"]"))
            .put("serial", "2f930e2d2cfe083771f68e4fe7bb07")
            .put("vendorId", "com.lge");
        JSONObject signature = new JSONObject().put("signature", sig).put("signatureVersion", 1);
        return new JSONObject().put("manifestVersion", 1).put("appVersion", "1.1")
            .put("permissions", new JSONArray("[\"LAUNCH\",\"CONTROL_AUDIO\",\"CONTROL_INPUT_TV\",\"CONTROL_INPUT_MEDIA_PLAYBACK\",\"CONTROL_POWER\",\"READ_APP_STATUS\",\"READ_INPUT_DEVICE_LIST\",\"READ_RUNNING_APPS\",\"READ_SETTINGS\",\"CONTROL_MOUSE_AND_KEYBOARD\"]"))
            .put("signatures", new JSONArray().put(signature)).put("signed", signed);
    }
    private void register(WebSocket ws) {
        try {
            JSONObject payload = new JSONObject().put("forcePairing", false).put("pairingType", "PROMPT")
                    .put("manifest", registrationManifest());
            String key = prefs.getString("key_" + currentIp, "");
            if (!key.isEmpty()) payload.put("client-key", key);
            ws.send(new JSONObject().put("type", "register").put("id", "register_0")
                    .put("payload", payload).toString());
        } catch (Exception e) { state("Ошибка регистрации: " + e.getMessage(), false); }
    }
    private void receive(String raw) {
        try {
            JSONObject obj = new JSONObject(raw);
            String type = obj.optString("type");
            JSONObject payload = obj.optJSONObject("payload");
            if (payload == null) payload = new JSONObject();
            if ("registered".equals(type)) {
                String key = payload.optString("client-key");
                if (!key.isEmpty()) prefs.edit().putString("key_" + currentIp, key).apply();
                registered = true;
                state("Подключено · " + currentIp, true);
                request("ssap://com.webos.service.networkinput/getPointerInputSocket", null, "pointer");
                request("ssap://audio/getVolume", null, "volume");
                subscribeVolume();
            } else if ("error".equals(type)) {
                String id = obj.optString("id");
                if (id.startsWith("register")) state("ТВ отклонил сопряжение. Повторите подключение.", false);
                else if (id.equals("pointer")) state("Пульт подключён, но навигация недоступна", true);
            } else if ("response".equals(type) && payload.has("pairingType")) {
                state("Разрешите подключение на экране телевизора", false);
            } else if ("response".equals(type) || "subscribe".equals(type)) {
                String id = obj.optString("id");
                if (id.equals("pointer")) {
                    String path = payload.optString("socketPath");
                    if (!path.isEmpty()) connectPointer(path);
                } else if (id.equals("inputs")) {
                    JSONArray list = payload.optJSONArray("devices");
                    if (list != null) { JSONArray finalList = list; main.post(() -> listener.inputs(finalList)); }
                }
                if (payload.has("volume") || payload.has("muted")) {
                    muted = payload.optBoolean("muted", muted);
                    int vol = payload.optInt("volume", -1);
                    boolean m = muted;
                    main.post(() -> listener.volume(vol, m));
                }
            }
        } catch (Exception ignored) { }
    }
    private void connectPointer(String path) {
        try {
            if (!path.startsWith("ws://") && !path.startsWith("wss://")) return;
            // The socketPath URL is supplied by the previously paired TV.
            String host = new java.net.URI(path).getHost();
            if (!currentIp.equals(host)) return;
            if (pointer != null) pointer.close(1000, "replacing");
            pointer = client.newWebSocket(new Request.Builder().url(path).build(), new WebSocketListener() {
                @Override public void onOpen(WebSocket webSocket, Response response) { state("Пульт готов · " + currentIp, true); }
                @Override public void onFailure(WebSocket webSocket, Throwable t, Response response) { state("Навигация недоступна; громкость работает", true); }
            });
        } catch (Exception ignored) { }
    }
    private void subscribeVolume() {
        send("subscribe", "ssap://audio/getVolume", null, "subvolume");
    }
    private void send(String type, String uri, JSONObject payload, String id) {
        if (!registered || socket == null) return;
        try {
            JSONObject obj = new JSONObject().put("type", type).put("id", id).put("uri", uri);
            if (payload != null) obj.put("payload", payload);
            socket.send(obj.toString());
        } catch (Exception ignored) { }
    }
    public void request(String uri, JSONObject payload, String id) { send("request", uri, payload, id); }
    public void action(String uri) { request(uri, null, "cmd_" + counter.getAndIncrement()); }
    public void button(String key) {
        if (pointer == null || !registered) { state("Пульт ещё подключается…", registered); return; }
        pointer.send("type:button\nname:" + key.toUpperCase(Locale.ROOT) + "\n\n");
    }
    public void setMute(boolean value) {
        try { request("ssap://audio/setMute", new JSONObject().put("mute", value), "cmd_" + counter.getAndIncrement()); }
        catch (Exception ignored) { }
    }
    public void toggleMute() { setMute(!muted); }
    public void showInputs() { request("ssap://tv/getExternalInputList", null, "inputs"); }
    public void selectInput(String id) {
        try { request("ssap://tv/switchInput", new JSONObject().put("inputId", id), "cmd_" + counter.getAndIncrement()); }
        catch (Exception ignored) { }
    }
    public void launch(String appId) {
        try { request("ssap://system.launcher/launch", new JSONObject().put("id", appId), "cmd_" + counter.getAndIncrement()); }
        catch (Exception ignored) { }
    }
    public boolean isRegistered() { return registered; }
    public void close() {
        epoch++;
        registered = false;
        if (pointer != null) { pointer.close(1000, "switch"); pointer = null; }
        if (socket != null) { socket.close(1000, "switch"); socket = null; }
    }
    public void forgetKey(String ip) { prefs.edit().remove("key_" + ip).apply(); }
    private void state(String msg, boolean connected) { main.post(() -> listener.state(msg, connected)); }
}
